// Main JavaScript for SENTINEL mockup

// Global variables
let globe;
let suppliers = [];
let activeSupplier = null;
let simulationActive = false;

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Handle loading screen
    setTimeout(function() {
        document.getElementById('loading-screen').style.display = 'none';
        document.getElementById('app').style.display = 'flex';
        initializeApplication();
    }, 4000); // Show loading screen for 4 seconds
});

// Initialize the application
function initializeApplication() {
    // Initialize the globe visualization
    initGlobe();
    
    // Initialize charts
    initCharts();
    
    // Initialize the redistribution visualization
    initRedistributionVisualization();
    
    // Set up event listeners
    setupEventListeners();
    
    // Update the date and time
    updateDateTime();
    setInterval(updateDateTime, 60000); // Update every minute
}

// Update the date and time display
function updateDateTime() {
    const now = new Date();
    const options = { 
        month: 'long', 
        day: 'numeric', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    };
    const formattedDate = now.toLocaleDateString('en-US', options);
    document.querySelector('.date-time').textContent = formattedDate.replace(',', '') + ' EDT';
}

// Initialize the globe visualization
function initGlobe() {
    // Create a scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);
    
    // Create a camera
    const camera = new THREE.PerspectiveCamera(75, document.getElementById('globe-visualization').offsetWidth / document.getElementById('globe-visualization').offsetHeight, 0.1, 1000);
    camera.position.z = 200;
    
    // Create a renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(document.getElementById('globe-visualization').offsetWidth, document.getElementById('globe-visualization').offsetHeight);
    document.getElementById('globe-visualization').appendChild(renderer.domElement);
    
    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0x404040);
    scene.add(ambientLight);
    
    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);
    
    // Create Earth globe
    const earthGeometry = new THREE.SphereGeometry(100, 64, 64);
    const earthMaterial = new THREE.MeshPhongMaterial({
        color: 0x2233ff,
        emissive: 0x112244,
        specular: 0x112233,
        shininess: 30
    });
    globe = new THREE.Mesh(earthGeometry, earthMaterial);
    scene.add(globe);
    
    // Add grid lines to represent latitude and longitude
    const gridHelper = new THREE.GridHelper(200, 10);
    gridHelper.rotation.x = Math.PI / 2;
    scene.add(gridHelper);
    
    // Create supplier nodes
    createSupplierNodes(scene);
    
    // Animation loop
    function animate() {
        requestAnimationFrame(animate);
        
        // Rotate the globe slowly
        globe.rotation.y += 0.001;
        
        // Update supplier positions
        updateSupplierPositions();
        
        renderer.render(scene, camera);
    }
    
    animate();
    
    // Add zoom controls
    document.getElementById('zoom-in').addEventListener('click', function() {
        camera.position.z -= 10;
    });
    
    document.getElementById('zoom-out').addEventListener('click', function() {
        camera.position.z += 10;
    });
    
    document.getElementById('reset-view').addEventListener('click', function() {
        camera.position.z = 200;
    });
    
    // Handle window resize
    window.addEventListener('resize', function() {
        camera.aspect = document.getElementById('globe-visualization').offsetWidth / document.getElementById('globe-visualization').offsetHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(document.getElementById('globe-visualization').offsetWidth, document.getElementById('globe-visualization').offsetHeight);
    });
}

// Create supplier nodes
function createSupplierNodes(scene) {
    // Define supplier data
    const supplierData = [
        { id: 1, name: "Precision Components Ltd.", location: "Shanghai, China", status: "critical", coordinates: { lat: 31.2304, lng: 121.4737 } },
        { id: 2, name: "TechSys Inc.", location: "California, USA", status: "warning", coordinates: { lat: 37.7749, lng: -122.4194 } },
        { id: 3, name: "GlobalTech Manufacturing", location: "Mexico City, Mexico", status: "warning", coordinates: { lat: 19.4326, lng: -99.1332 } },
        { id: 4, name: "ElectroParts GmbH", location: "Munich, Germany", status: "normal", coordinates: { lat: 48.1351, lng: 11.5820 } },
        { id: 5, name: "MicroTech Industries", location: "Penang, Malaysia", status: "normal", coordinates: { lat: 5.4141, lng: 100.3288 } },
        { id: 6, name: "Advanced Components Inc.", location: "Monterrey, Mexico", status: "normal", coordinates: { lat: 25.6866, lng: -100.3161 } },
        { id: 7, name: "Quantum Electronics", location: "Tokyo, Japan", status: "normal", coordinates: { lat: 35.6762, lng: 139.6503 } },
        { id: 8, name: "Integrated Systems Ltd.", location: "Bangalore, India", status: "normal", coordinates: { lat: 12.9716, lng: 77.5946 } },
        { id: 9, name: "Nordic Precision", location: "Stockholm, Sweden", status: "normal", coordinates: { lat: 59.3293, lng: 18.0686 } },
        { id: 10, name: "Southern Manufacturing", location: "Sydney, Australia", status: "normal", coordinates: { lat: -33.8688, lng: 151.2093 } },
        { id: 11, name: "Atlantic Devices", location: "Boston, USA", status: "normal", coordinates: { lat: 42.3601, lng: -71.0589 } },
        { id: 12, name: "Pacific Instruments", location: "Singapore", status: "normal", coordinates: { lat: 1.3521, lng: 103.8198 } }
    ];
    
    // Create a node for each supplier
    supplierData.forEach(supplier => {
        // Convert lat/lng to 3D coordinates
        const position = latLngToVector3(supplier.coordinates.lat, supplier.coordinates.lng, 100);
        
        // Create a sphere for the supplier node
        const nodeGeometry = new THREE.SphereGeometry(2, 16, 16);
        
        // Set color based on status
        let nodeColor;
        switch(supplier.status) {
            case 'critical':
                nodeColor = 0xdc3545; // Red
                break;
            case 'warning':
                nodeColor = 0xffc107; // Yellow
                break;
            case 'normal':
                nodeColor = 0x28a745; // Green
                break;
            default:
                nodeColor = 0x999999; // Gray
        }
        
        const nodeMaterial = new THREE.MeshBasicMaterial({ color: nodeColor });
        const node = new THREE.Mesh(nodeGeometry, nodeMaterial);
        
        // Position the node
        node.position.set(position.x, position.y, position.z);
        
        // Add to scene
        scene.add(node);
        
        // Store supplier data with node reference
        suppliers.push({
            ...supplier,
            node: node,
            originalPosition: { ...position },
            originalStatus: supplier.status
        });
    });
}

// Convert latitude and longitude to 3D vector
function latLngToVector3(lat, lng, radius) {
    const phi = (90 - lat) * (Math.PI / 180);
    const theta = (lng + 180) * (Math.PI / 180);
    
    const x = -radius * Math.sin(phi) * Math.cos(theta);
    const y = radius * Math.cos(phi);
    const z = radius * Math.sin(phi) * Math.sin(theta);
    
    return { x, y, z };
}

// Update supplier positions based on globe rotation
function updateSupplierPositions() {
    suppliers.forEach(supplier => {
        // Apply the same rotation as the globe
        const rotatedPosition = {
            x: supplier.originalPosition.x * Math.cos(globe.rotation.y) - supplier.originalPosition.z * Math.sin(globe.rotation.y),
            y: supplier.originalPosition.y,
            z: supplier.originalPosition.x * Math.sin(globe.rotation.y) + supplier.originalPosition.z * Math.cos(globe.rotation.y)
        };
        
        supplier.node.position.set(rotatedPosition.x, rotatedPosition.y, rotatedPosition.z);
    });
}

// Initialize charts
function initCharts() {
    // Risk forecast chart
    const ctx = document.getElementById('risk-forecast-chart').getContext('2d');
    const riskForecastChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Today', 'Apr 19', 'Apr 20', 'Apr 21', 'Apr 22', 'Apr 23', 'Apr 24'],
            datasets: [
                {
                    label: 'Supply Risk Index',
                    data: [42, 38, 35, 30, 28, 25, 22],
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Logistics Risk Index',
                    data: [28, 30, 32, 35, 33, 30, 28],
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Overall Risk Index',
                    data: [35, 34, 33, 32, 30, 27, 25],
                    borderColor: '#0076CE',
                    backgroundColor: 'rgba(0, 118, 206, 0.1)',
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Risk Index (0-100)'
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            }
        }
    });
}

// Initialize the redistribution visualization
function initRedistributionVisualization() {
    // Create a simple force-directed graph using D3.js
    const width = document.getElementById('redistribution-visualization').offsetWidth;
    const height = document.getElementById('redistribution-visualization').offsetHeight;
    
    const svg = d3.select('#redistribution-visualization')
        .append('svg')
        .attr('width', width)
        .attr('height', height);
    
    // Define nodes
    const nodes = [
        { id: 'source', name: 'Precision Components Ltd.', type: 'source', x: width / 2, y: height / 2 },
        { id: 'target1', name: 'ElectroParts GmbH', type: 'target', x: width / 4, y: height / 4 },
        { id: 'target2', name: 'MicroTech Industries', type: 'target', x: width * 3/4, y: height / 4 },
        { id: 'target3', name: 'Advanced Components Inc.', type: 'target', x: width / 2, y: height * 3/4 }
    ];
    
    // Define links
    const links = [
        { source: 'source', target: 'target1', value: 35 },
        { source: 'source', target: 'target2', value: 25 },
        { source: 'source', target: 'target3', value: 25 }
    ];
    
    // Create a force simulation
    const simulation = d3.forceSimulation(nodes)
        .force('link', d3.forceLink(links).id(d => d.id).distance(100))
        .force('charge', d3.forceManyBody().strength(-300))
        .force('center', d3.forceCenter(width / 2, height / 2))
        .on('tick', ticked);
    
    // Create links
    const link = svg.append('g')
        .selectAll('line')
        .data(links)
        .enter()
        .append('line')
        .attr('stroke-width', d => Math.sqrt(d.value))
        .attr('stroke', '#999')
        .attr('stroke-opacity', 0.6);
    
    // Create nodes
    const node = svg.append('g')
        .selectAll('g')
        .data(nodes)
        .enter()
        .append('g');
    
    // Add circles to nodes
    node.append('circle')
        .attr('r', d => d.type === 'source' ? 20 : 15)
        .attr('fill', d => d.type === 'source' ? '#dc3545' : '#28a745');
    
    // Add text labels
    node.append('text')
        .attr('dx', 20)
        .attr('dy', 4)
        .text(d => d.name)
        .attr('font-size', '10px');
    
    // Add value labels to links
    svg.append('g')
        .selectAll('text')
        .data(links)
        .enter()
        .append('text')
        .attr('font-size', '10px')
        .attr('font-weight', 'bold')
        .text(d => `${d.value}%`);
    
    // Update positions on each tick
    function ticked() {
        link
            .attr('x1', d => d.source.x)
            .attr('y1', d => d.source.y)
            .attr('x2', d => d.target.x)
            .attr('y2', d => d.target.y);
        
        node
            .attr('transform', d => `translate(${d.x},${d.y})`);
        
        // Update link label positions
        svg.selectAll('text')
            .filter(function() { return this.parentNode.tagName === 'g' ? false : true; })
            .attr('x', function(d, i) {
                return (d.source.x + d.target.x) / 2;
            })
            .attr('y', function(d, i) {
                return (d.source.y + d.target.y) / 2;
            });
    }
}

// Set up event listeners
function setupEventListeners() {
    // Tab navigation
    document.querySelectorAll('.sidebar li').forEach(item => {
        item.addEventListener('click', function() {
            // Remove active class from all tabs
            document.querySelectorAll('.sidebar li').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Hide all tab content
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Show selected tab content
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Disruption management modal
    document.getElementById('manage-disruption').addEventListener('click', function() {
        document.getElementById('disruption-modal').style.display = 'flex';
    });
    
    document.querySelector('.simulate-response').addEventListener('click', function() {
        document.getElementById('disruption-modal').style.display = 'flex';
    });
    
    document.querySelector('.close-modal').addEventListener('click', function() {
        document.getElementById('disruption-modal').style.display = 'none';
    });
    
    // Implement redistribution plan
    document.getElementById('implement-redistribution').addEventListener('click', function() {
        this.textContent = 'Implementing...';
        this.disabled = true;
        
        setTimeout(() => {
            this.textContent = 'Implementation Complete';
            document.getElementById('confirm-plan').textContent = 'Close';
            
            // Update the globe visualization to show redistribution
            simulateRedistribution();
        }, 2000);
    });
    
    // Confirm plan button
    document.getElementById('confirm-plan').addEventListener('click', function() {
        if (this.textContent === 'Close') {
            document.getElementById('disruption-modal').style.display = 'none';
            
            // Update the alert to show it's being handled
            const criticalAlert = document.querySelector('.alert.critical');
            criticalAlert.querySelector('h4').textContent = 'Critical: Supplier Shutdown (Being Handled)';
            criticalAlert.querySelector('.simulate-response').textContent = 'View Plan';
            
            // Update the emergency event
            const criticalEvent = document.querySelector('.event.critical');
            criticalEvent.querySelector('.event-status').textContent = 'Mitigating';
            
            // Show a notification
            showNotification('Load redistribution plan implemented successfully. Monitoring alternative suppliers for capacity.');
        } else {
            // Implement the plan
            document.getElementById('implement-redistribution').click();
        }
    });
}

// Simulate redistribution of supplier load
function simulateRedistribution() {
    // Find the critical supplier
    const criticalSupplier = suppliers.find(s => s.status === 'critical');
    if (!criticalSupplier) return;
    
    // Find the alternative suppliers
    const alternativeSuppliers = suppliers.filter(s => 
        s.name === "ElectroParts GmbH" || 
        s.name === "MicroTech Industries" || 
        s.name === "Advanced Components Inc."
    );
    
    // Update the visualization
    alternativeSuppliers.forEach(supplier => {
        // Make the node pulse to indicate increased load
        const originalScale = supplier.node.scale.x;
        
        // Animation to show load transfer
        const animate = () => {
            const scale = 1 + 0.2 * Math.sin(Date.now() * 0.005);
            supplier.node.scale.set(scale, scale, scale);
            
            if (simulationActive) {
                requestAnimationFrame(animate);
            } else {
                supplier.node.scale.set(1.2, 1.2, 1.2);
            }
        };
        
        simulationActive = true;
        animate();
        
        // Change color to indicate higher load
        supplier.node.material.color.set(0xFF7900); // Honeywell orange
    });
}

// Show a notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-info-circle"></i>
            <span>${message}</span>
        </div>
        <button class="close-notification">&times;</button>
    `;
    
    // Style the notification
    notification.style.position = 'fixed';
    notification.style.bottom = '20px';
    notification.style.right = '20px';
    notification.style.backgroundColor = 'white';
    notification.style.padding = '15px';
    notification.style.borderRadius = '4px';
    notification.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
    notification.style.zIndex = '1000';
    notification.style.display = 'flex';
    notification.style.alignItems = 'center';
    notification.style.justifyContent = 'space-between';
    notification.style.maxWidth = '400px';
    
    // Add to the document
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.5s';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 500);
    }, 5000);
    
    // Close button
    notification.querySelector('.close-notification').addEventListener('click', function() {
        document.body.removeChild(notification);
    });
}
